#include <algorithm>
#include <cstdio>
using namespace std;
const int N = 1e5 + 10;
int n, x;
int T[N];
int main() {
    scanf("%d %d", &n, &x);
    for (int i = 1; i <= n; ++i)
        scanf("%d", &T[i]);
    sort(T + 1, T + 1 + n);
    int j = 0;
    j = lower_bound(T + 1, T + 1 + n, x) - T;
    if (j == n + 1)
        j = 0;
    printf("%d\n", j);
    return 0;
}